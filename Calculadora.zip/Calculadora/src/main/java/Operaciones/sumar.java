
package Operaciones;

import java.util.Scanner;

public class sumar {
    
    public static int sumarVariables(){
        
        // 1. requisitos, identificar mis variables
        int numero1;
        int numero2;
        int resultado;
        
        // 2. realizar proceso 
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("Ingrese numero1");
        numero1=scanner.nextInt();
        
        System.out.println("Ingrese numero2");
        numero2=scanner.nextInt();
        
        resultado=numero1+numero2;
        
        return resultado;   //retorna el resultado de la suma 
        
    }
}
