
package com.mycompany.calculadora;

import Operaciones.sumar;
import Operaciones.resta;
import Operaciones.multiplicar;
import Operaciones.dividir;

public class Calculadora {

    public static void main(String[] args) {
        // Llamamos a los métodos de las clases Operaciones
        int sumaResultado = sumar.sumarVariables();
        System.out.println("La suma de los dos numeros es: " + sumaResultado);

        int restaResultado = resta.restaVariables();
        System.out.println("La resta de los dos numeros es: " + restaResultado);

        int multiplicarResultado = multiplicar.multiplicarVariables();
        System.out.println("La multiplicacion de los dos numeros es: " + multiplicarResultado);

        double dividirResultado = dividir.dividirVariables();
        System.out.println("La division de los dos numeros es: " + dividirResultado);
    }
}
